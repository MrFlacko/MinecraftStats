DDDDDDDDDDDDD       333333333333333   XXXXXXX       XXXXXXX
D::::::::::::DDD   3:::::::::::::::33 X:::::X       X:::::X
D:::::::::::::::DD 3::::::33333::::::3X:::::X       X:::::X
DDD:::::DDDDD:::::D3333333     3:::::3X::::::X     X::::::X
  D:::::D    D:::::D           3:::::3XXX:::::X   X:::::XXX
  D:::::D     D:::::D          3:::::3   X:::::X X:::::X   
  D:::::D     D:::::D  33333333:::::3     X:::::X:::::X    
  D:::::D     D:::::D  3:::::::::::3       X:::::::::X     
  D:::::D     D:::::D  33333333:::::3      X:::::::::X     
  D:::::D     D:::::D          3:::::3    X:::::X:::::X    
  D:::::D     D:::::D          3:::::3   X:::::X X:::::X   
  D:::::D    D:::::D           3:::::3XXX:::::X   X:::::XXX
DDD:::::DDDDD:::::D3333333     3:::::3X::::::X     X::::::X
D:::::::::::::::DD 3::::::33333::::::3X:::::X       X:::::X
D::::::::::::DDD   3:::::::::::::::33 X:::::X       X:::::X
DDDDDDDDDDDDD       333333333333333   XXXXXXX       XXXXXXX

MC Generic is a HTML5/CSS3 template that looks great for
any Minecraft themed website. It is provided Free of Charge
by D3X Solutions under the GNU General Public License,
version 2 or later (GNU GPL 2).

Known Bugs/Quirks List: ([X] Indicates fixed since last version)

[-] Article Content approximately 45px down from where I
    want it aesthetically. This is due to the :before
    property, the main journal background will overlap.
    There is a rough fix if one adds extra wrappers inside
    the article and negatively push the text up.

[ ] Large images inside the article content area may leak
    into the sidebar and beyond.


Upcoming Features:
[X] Better CSS Buttons
[X] Improved Sidebar elements (lists, menus, etc)
[X] IE6 Support
[ ] Full Page Layout
[ ] Responsive Design (for cell phones to use)
[ ] Script for finding server status (online or offline)
[ ] Style #2: Fantasy
[ ] WordPress

###########################################################
### Project Information                                 ###
### Template:   MC Generic                              ###
### Version:    1.03                                    ###
### Release:    09 July 2012                            ###
### Author:     D3X Solutions - Seth Moon               ###
### URL:        design.d3x.co/demo/mcgeneric            ###
### Copyright:  2012 D3X Solutions                      ###
### License:    GNU GPL 2                               ###
###########################################################
#!/bin/bash
terser --source-map -o mcstats.min.js dev/mcstats.js dev/mcstats-widgets.js dev/mcstats-awardlist.js dev/mcstats-awardview.js dev/mcstats-eventlist.js dev/mcstats-eventview.js dev/mcstats-playerlist.js dev/mcstats-playerview.js dev/mcstats-hof.js dev/mcstats-loader.js dev/mcstats-start.js
